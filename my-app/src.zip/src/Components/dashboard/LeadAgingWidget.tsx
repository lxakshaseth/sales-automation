"use client";

import { useEffect, useState } from "react";

interface LeadAging {
  id: string;
  name: string;
  company: string;
  email: string;
  stage: string;
  lastActivity: string;
  agingDays: number;
}

export default function LeadAgingWidget() {
  const [leads, setLeads] = useState<LeadAging[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/dashboard/lead-aging")
      .then((res) => res.json())
      .then((data) => {
        setLeads(data.data || []);
        setLoading(false);
        })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

    const getBadgeColor = (days: number) => {
    if (days <= 3) {
        return "bg-green-100 text-green-700 border border-green-300";
    }

    if (days <= 7) {
        return "bg-yellow-100 text-yellow-700 border border-yellow-300";
    }

    if (days <= 14) {
        return "bg-orange-100 text-orange-700 border border-orange-300";
    }

    return "bg-red-100 text-red-700 border border-red-300";
    };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-semibold text-slate-900">
          Lead Aging Tracker
        </h2>

        <span className="text-sm text-slate-500">
          Stuck Leads Monitoring
        </span>
      </div>

      {loading ? (
        <div className="text-slate-500 text-sm">
          Loading...
        </div>
      ) : (
        <div className="space-y-4">
          {leads.length === 0 ? (
            <p className="text-slate-500 text-sm">
              No Leads Found
            </p>
          ) : (
            leads.map((lead) => (
              <div
                key={lead.id}
                className="border border-slate-200 rounded-2xl p-4 hover:shadow-md transition-all"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-slate-900">
                      {lead.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                    {lead.company}
                    </p>
                    <span
                        className="
                            inline-flex
                            px-2
                            py-1
                            mt-2
                            rounded-full
                            text-xs
                            bg-violet-100
                            text-violet-700
                        "
                        >
                        {lead.stage}
                        </span>

                        <div className="mt-2">
                        <p className="text-xs text-slate-400">
                            {lead.lastActivity}
                        </p>

                        <p className="text-xs text-slate-500 mt-1">
                            Stuck for {lead.agingDays} days
                        </p>
                        </div>
                  </div>

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${getBadgeColor(
                      lead.agingDays
                    )}`}
                  >
                    {lead.agingDays} Days
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}