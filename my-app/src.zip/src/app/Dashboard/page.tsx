"use client";

import { DashboardHeader } from "@/Components/dashboard/StatsCards";
import LeadAgingWidget from "@/Components/dashboard/LeadAgingWidget";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import SideBar from "@/Components/SideBar";
import EmailStats from "@/Components/dashboard/EmailStats";

export default function DashboardPage() {
  const router = useRouter();
  const [isCollapsed, setIsCollapsed] = useState(false);

  useEffect(() => {
    const token = sessionStorage.getItem("token");

    if (!token) {
      router.replace("/sign-in");
    }
  }, [router]);

  return (
    <div className="flex min-h-screen bg-[#f8fafc] overflow-hidden">
      {/* Sidebar */}
      <SideBar
        isCollapsed={isCollapsed}
        onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
      />

      <main
        className={`flex-1 transition-all duration-300 overflow-y-auto ${
          isCollapsed ? "ml-22.5" : "ml-67.5"
        }`}
      >
        <div className="p-6 lg:p-8">
          <DashboardHeader />

          <div className="mt-6 pb-8 max-w-3xl">
            <EmailStats />
          </div>

          <div className="mt-4 pb-6">
            <LeadAgingWidget />
          </div>
          
        </div>
      </main>
    </div>
  );
}